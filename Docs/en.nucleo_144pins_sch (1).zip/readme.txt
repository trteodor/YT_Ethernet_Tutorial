By using or installing (as applicable) this package, you accept all the terms of the Reference Material
license agreement available at : www.st.com/opla